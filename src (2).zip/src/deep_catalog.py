﻿import json
import re
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
import httpx
from bs4 import BeautifulSoup
from packaging import version
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()
BASE_DIR = Path("C:/DriverManager")
CAB_DIR = BASE_DIR / "downloads" / "cab_temp"
SEVEN_ZIP = Path("C:/Program Files/7-Zip/7z.exe")
NO_WIN = subprocess.CREATE_NO_WINDOW

HWID_PATTERN = re.compile(
    r"(PCI\\VEN_[0-9A-F]{4}&DEV_[0-9A-F]{4}|"
    r"HDAUDIO\\FUNC_[0-9A-F]{2}&VEN_[0-9A-F]{4}&DEV_[0-9A-F]{4}|"
    r"USB\\VID_[0-9A-F]{4}&PID_[0-9A-F]{4})",
    re.IGNORECASE
)

def extract_generic_hwid(raw_id: str) -> str | None:
    if not raw_id:
        return None
    match = HWID_PATTERN.search(raw_id)
    return match.group(1).upper() if match else None

def parse_wmi_date(wmi_date: str) -> datetime:
    if wmi_date and len(wmi_date) >= 8:
        try:
            return datetime.strptime(wmi_date[:8], "%Y%m%d")
        except ValueError:
            pass
    return datetime(2000, 1, 1)

def parse_catalog_date(date_str: str) -> datetime:
    for fmt in ("%m/%d/%Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(date_str.strip(), fmt)
        except ValueError:
            continue
    return datetime(2000, 1, 1)

def query_ms_catalog(client: httpx.Client, generic_hwid: str, local_ver: str, local_date: datetime):
    """Cerca sul Microsoft Update Catalog.

    Ritorna (candidato, ok): ok=False se la ricerca è fallita (rete, pagina inattesa, ...),
    così il chiamante non scambia un errore per "nessun aggiornamento".
    """
    url = "https://www.catalog.update.microsoft.com/Search.aspx"
    try:
        # Accept-Language fisso: il formato delle date nel Catalog dipende dalla lingua
        resp = client.get(url, params={"q": generic_hwid}, timeout=12.0,
                          headers={"Accept-Language": "en-US,en;q=0.9"})
        if resp.status_code != 200:
            return None, False

        # Nessun risultato: il Catalog lo dice esplicitamente (pagina in inglese grazie ad Accept-Language).
        # Una pagina senza tabella e senza questo messaggio (errore, throttling) conta come fallimento.
        if "ctl00_catalogBody_updateMatches" not in resp.text:
            return None, "did not find any results" in resp.text.lower()

        soup = BeautifulSoup(resp.text, "html.parser")
        table = soup.find("table", id="ctl00_catalogBody_updateMatches")
        if not table:
            return None, False

        best_candidate = None
        best_ver = version.parse(local_ver)

        for row in table.find_all("tr")[1:]:
            cols = row.find_all("td")
            if len(cols) < 8:
                continue

            title = cols[1].get_text(strip=True)
            products = cols[2].get_text(strip=True)
            date_str = cols[4].get_text(strip=True)
            ver_str = cols[5].get_text(strip=True)
            btn = cols[7].find("input")

            if not ("Windows 11" in products or "Windows 10" in products):
                continue
            if not btn or not btn.get("id"):
                continue

            try:
                rem_ver = version.parse(ver_str)
                rem_date = parse_catalog_date(date_str)
            except Exception:
                continue

            if rem_ver > best_ver and rem_date >= local_date:
                best_ver = rem_ver
                best_candidate = {
                    "title": title,
                    "remote_ver": ver_str,
                    "remote_date": rem_date.strftime("%Y-%m-%d"),
                    "update_id": btn.get("id")
                }

        return best_candidate, True
    except Exception:
        return None, False

def deep_scan_peripherals(wmi_client):
    """Scansiona tutte le periferiche confrontandole col database globale Microsoft."""
    console.print("\n[bold cyan][Deep Scan] Controllo globale periferiche (PCI, USB, Audio, LAN, Chipset)...[/bold cyan]")
    devices_to_check = {}

    for drv in wmi_client.Win32_PnPSignedDriver():
        if not drv.DeviceName or not drv.DriverVersion:
            continue
        if drv.DriverProviderName in ("Microsoft", None) or "NVIDIA" in (drv.DeviceName or ""):
            continue

        gen_id = extract_generic_hwid(drv.HardWareID or drv.DeviceID)
        if not gen_id or gen_id in devices_to_check:
            continue

        devices_to_check[gen_id] = {
            "name": drv.DeviceName,
            "provider": drv.DriverProviderName or "OEM",
            "local_ver": drv.DriverVersion,
            "local_date": parse_wmi_date(drv.DriverDate),
            "hwid": gen_id
        }

    updates_found = []
    failed_checks = 0
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]{task.description}"),
        console=console
    ) as progress:
        task = progress.add_task("Interrogazione Microsoft Update Catalog...", total=len(devices_to_check))
        with httpx.Client(headers=headers, follow_redirects=True) as client:
            # Poche richieste in parallelo: più veloce, ma senza martellare il Catalog
            with ThreadPoolExecutor(max_workers=4) as pool:
                futures = {
                    pool.submit(query_ms_catalog, client, hwid, info["local_ver"], info["local_date"]): (hwid, info)
                    for hwid, info in devices_to_check.items()
                }
                for fut in as_completed(futures):
                    hwid, info = futures[fut]
                    progress.update(task, description=f"Controllo: {info['name'][:40]} ({hwid})...")
                    try:
                        res, ok = fut.result()
                    except Exception:
                        res, ok = None, False
                    if not ok:
                        failed_checks += 1
                    elif res:
                        info.update(res)
                        updates_found.append(info)
                    progress.advance(task)

    updates_found.sort(key=lambda i: i["name"].lower())

    if failed_checks:
        console.print(
            f"[yellow]! {failed_checks} controlli su {len(devices_to_check)} non sono riusciti "
            f"(rete o Catalog non raggiungibile): il risultato è parziale.[/yellow]"
        )

    if not updates_found:
        if failed_checks:
            console.print("[yellow]! Nessun aggiornamento trovato, ma la scansione non è completa. Riprova più tardi.[/yellow]")
        else:
            console.print("[bold green]✔ Tutte le periferiche PCI/USB/Audio hanno già l'ultimo driver WHQL disponibile![/bold green]")
        return []

    table = Table(title="Aggiornamenti Periferiche Trovati (Deep Catalog Match)")
    table.add_column("#", style="cyan")
    table.add_column("Periferica", style="white")
    table.add_column("Hardware ID", style="dim")
    table.add_column("Installato", style="yellow")
    table.add_column("Nuova Versione WHQL", style="bold green")

    for idx, item in enumerate(updates_found, 1):
        table.add_row(
            str(idx),
            item["name"][:35],
            item["hwid"],
            f"{item['local_ver']} ({item['local_date'].strftime('%Y-%m-%d')})",
            f"{item['remote_ver']} ({item['remote_date']})"
        )

    console.print(table)
    return updates_found

def install_catalog_cab_updates(updates_list) -> tuple[int, int]:
    """Scarica i pacchetti .cab dal Microsoft Update Catalog (evitando duplicati) e li installa.

    Ritorna (installati, falliti).
    """
    if not updates_list:
        return 0, 0

    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
    done_uids = set()
    ok_count = 0
    fail_count = 0

    with httpx.Client(headers=headers, follow_redirects=True, timeout=30.0) as client:
        for item in updates_list:
            uid = item["update_id"]
            if uid in done_uids:
                console.print(f"[dim] -> Pacchetto già elaborato per {item['name']}, salto download duplicato.[/dim]")
                continue

            console.print(f"\n[bold cyan]Richiesta link download per:[/bold cyan] {item['name']} ({item['remote_ver']})")
            try:
                post_url = "https://www.catalog.update.microsoft.com/DownloadDialog.aspx"
                payload = {"updateIDs": json.dumps([{"size": 0, "languages": "", "uidInfo": uid, "updateID": uid}])}
                resp = client.post(post_url, data=payload)
                resp.raise_for_status()

                cab_links = re.findall(r"https?://[^\s'\"]+\.cab", resp.text)
                if not cab_links:
                    console.print(f"[red]✖ Impossibile estrarre il link .cab per {item['name']}[/red]")
                    fail_count += 1
                    continue

                cab_url = cab_links[0]
                if CAB_DIR.exists():
                    shutil.rmtree(CAB_DIR, ignore_errors=True)
                CAB_DIR.mkdir(parents=True, exist_ok=True)

                cab_path = CAB_DIR / "driver_pkg.cab"
                extract_path = CAB_DIR / "extracted"
                extract_path.mkdir(exist_ok=True)

                console.print(f" -> Download ed estrazione di {cab_url.split('/')[-1]}...")
                with client.stream("GET", cab_url) as dl_resp:
                    dl_resp.raise_for_status()
                    with open(cab_path, "wb") as f:
                        for chunk in dl_resp.iter_bytes(65536):
                            f.write(chunk)

                if SEVEN_ZIP.exists():
                    ext = subprocess.run(
                        [str(SEVEN_ZIP), "x", str(cab_path), f"-o{extract_path}", "-y"],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        creationflags=NO_WIN
                    )
                else:
                    ext = subprocess.run(
                        ["expand.exe", str(cab_path), "-F:*", str(extract_path)],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        creationflags=NO_WIN
                    )
                if ext.returncode != 0 or not any(extract_path.rglob("*.inf")):
                    console.print(f"[red]✖ Estrazione del pacchetto non riuscita per {item['name']} (nessun .inf trovato).[/red]")
                    fail_count += 1
                    continue

                console.print(f" -> Installazione {item['name']} tramite pnputil...")
                res = subprocess.run(
                    ["pnputil", "/add-driver", str(extract_path / "*.inf"), "/subdirs", "/install"],
                    capture_output=True,
                    text=True,
                    encoding="oem",
                    errors="replace",
                    creationflags=NO_WIN
                )

                # Solo il codice di ritorno decide l'esito (il testo di pnputil dipende dalla lingua di Windows)
                if res.returncode in (0, 3010):
                    console.print(f"[bold green]✔ {item['name']} aggiornato alla versione {item['remote_ver']}![/bold green]")
                    if res.returncode == 3010:
                        console.print("[bold yellow]! Riavvio del sistema consigliato.[/bold yellow]")
                    done_uids.add(uid)
                    ok_count += 1
                else:
                    out_msg = (res.stdout or "").strip().replace("\n", " ")[:160]
                    console.print(f"[bold red]✖ Installazione di {item['name']} non riuscita (pnputil codice {res.returncode}): {out_msg}[/bold red]")
                    fail_count += 1
            except Exception as e:
                console.print(f"[bold red]✖ Errore su {item['name']}: {e}[/bold red]")
                fail_count += 1
            finally:
                shutil.rmtree(CAB_DIR, ignore_errors=True)

    console.print(f"\n[bold cyan]Riepilogo installazione: {ok_count} riusciti, {fail_count} falliti.[/bold cyan]")
    return ok_count, fail_count


def cleanup_old_driver_packages() -> bool:
    """Pulizia componenti di sistema con DISM (WinSxS).

    NB: NON rimuove i pacchetti driver obsoleti dal DriverStore: conta solo i pacchetti OEM presenti.
    """
    console.print("\n[bold cyan]Analisi pacchetti driver archiviati nel DriverStore di Windows...[/bold cyan]")
    res = subprocess.run(
        ["pnputil", "/enum-drivers"],
        capture_output=True,
        text=True,
        encoding="oem",
        errors="replace",
        creationflags=NO_WIN
    )
    oem_count = len(re.findall(r"oem\d+\.inf", res.stdout or "", re.IGNORECASE))
    console.print(f"Pacchetti driver OEM totali archiviati in Windows: [bold yellow]{oem_count}[/bold yellow]")
    console.print("Avvio pulizia componenti di sistema (DISM StartComponentCleanup)...")
    dism = subprocess.run(
        ["Dism.exe", "/Online", "/Cleanup-Image", "/StartComponentCleanup"],
        capture_output=True,
        text=True,
        encoding="oem",
        errors="replace",
        check=False,
        creationflags=NO_WIN
    )
    code = dism.returncode & 0xFFFFFFFF  # Windows restituisce gli HRESULT come interi positivi enormi
    if code in (0, 3010):
        console.print("[bold green]✔ Pulizia componenti di sistema completata.[/bold green]")
        if code == 3010:
            console.print("[bold yellow]! Riavvio del sistema consigliato.[/bold yellow]")
        return True

    if code == 0x800F0806:
        console.print(
            "[bold yellow]! Windows ha un'operazione di aggiornamento in sospeso (0x800F0806): "
            "riavvia il PC e ripeti la pulizia.[/bold yellow]"
        )
    else:
        last = [l.strip() for l in (dism.stdout or "").splitlines() if l.strip()]
        detail = f" - {last[-1][:140]}" if last else ""
        console.print(f"[bold red]✖ DISM ha restituito l'errore 0x{code:08X}{detail}[/bold red]")
        console.print("[dim]Dettagli in C:\\Windows\\Logs\\DISM\\dism.log[/dim]")
    return False
