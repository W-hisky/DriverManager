﻿import ctypes
import math
import os
import re
import site
import sys
import threading
import traceback
from datetime import datetime
from pathlib import Path

BASE_DIR = Path("C:/DriverManager")
SRC_DIR = BASE_DIR / "src"
LOG_DIR = BASE_DIR / "logs"
BACKUP_DIR = BASE_DIR / "backups"
VENV_SITE = BASE_DIR / ".venv" / "Lib" / "site-packages"
LOG_DIR.mkdir(parents=True, exist_ok=True)
BACKUP_DIR.mkdir(parents=True, exist_ok=True)

try:
    if ctypes.windll.shell32.IsUserAnAdmin() == 0:
        py_exe = BASE_DIR / ".venv" / "Scripts" / "python.exe"
        if not py_exe.exists():
            py_exe = Path(sys.executable)
        script_path = Path(__file__).resolve()
        ctypes.windll.shell32.ShellExecuteW(
            None, "runas", str(py_exe), f'"{script_path}"', str(BASE_DIR), 1
        )
        sys.exit(0)

    hwnd = ctypes.windll.kernel32.GetConsoleWindow()
    if hwnd != 0:
        ctypes.windll.user32.ShowWindow(hwnd, 0)

    os.chdir(BASE_DIR)
    if VENV_SITE.exists():
        site.addsitedir(str(VENV_SITE))
    if str(SRC_DIR) not in sys.path:
        sys.path.insert(0, str(SRC_DIR))

    import pythoncom
    import wmi
    import tkinter as tk
    from tkinter import filedialog, messagebox
    import customtkinter as ctk
    from PIL import Image, ImageDraw, ImageFilter, ImageTk

    from driver_scanner import check_nvidia_update, console as ds_console
    from deep_catalog import (
        deep_scan_peripherals,
        install_catalog_cab_updates,
        cleanup_old_driver_packages,
        console as dc_console,
    )
    from driver_cleanup import (
        find_obsolete_driver_packages,
        remove_obsolete_driver_packages,
        console as cl_console,
    )
    from driver_installer import (
        backup_current_drivers,
        download_file,
        install_nvidia_driver,
        update_game_runtimes,
        create_system_restore_point,
        clean_gpu_shader_cache,
        enable_gpu_msi_mode,
        restore_driver_backup_folder,
        console as di_console,
    )

    ctk.set_appearance_mode("Light")
    ANSI_ESCAPE = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")

    class ModernEventInterceptor:
        def __init__(self, app):
            self.app = app
            self.log_file = LOG_DIR / "session_activity.log"

        def write(self, text: str):
            clean = ANSI_ESCAPE.sub("", text).strip()
            if not clean:
                return

            # Una riga di log per riga di testo, ciascuna con data e ora di scrittura
            stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            try:
                with open(self.log_file, "a", encoding="utf-8") as f:
                    for log_line in clean.splitlines():
                        if log_line.strip():
                            f.write(f"[{stamp}] {log_line.rstrip()}\n")
            except Exception:
                pass

            for line in clean.splitlines():
                s = line.strip()
                if not s or s.startswith(("─", "│", "╭", "╰", "┏", "┗", "===")):
                    continue

                if "✔" in s:
                    msg = s.replace("✔", "").strip()
                    self.app.after(0, self.app.show_toast, "Operazione Completata", msg, "success")
                elif "✖" in s or "[ERRORE]" in s:
                    msg = s.replace("✖", "").replace("[ERRORE]", "").strip()
                    self.app.after(0, self.app.show_toast, "Attenzione", msg, "error")
                elif s.startswith("!"):
                    msg = s.lstrip("!").strip()
                    self.app.after(0, self.app.show_toast, "Nota di Sistema", msg, "warning")
                elif any(k in s for k in ("Controllo:", "Avanzamento", "Avvio", "Pulizia", "Creazione", "Richiesta")):
                    clean_sub = s.replace("[Pro Toolkit]", "").replace("[Deep Scan]", "").strip()
                    self.app.after(0, self.app.update_live_subtitle, clean_sub[:90])

        def flush(self):
            pass

    def build_auralis_background(width: int, height: int, glass_cards: list) -> Image.Image:
        sw, sh = 275, 190
        bg = Image.new("RGBA", (sw, sh), (248, 249, 251, 255))

        aurora = Image.new("RGBA", (sw, sh), (0, 0, 0, 0))
        adraw = ImageDraw.Draw(aurora)
        adraw.ellipse([65, -18, 155, 48], fill=(216, 165, 228, 135))
        adraw.ellipse([115, -22, 210, 50], fill=(140, 208, 252, 150))
        adraw.ellipse([40, -5, 110, 42], fill=(244, 192, 208, 95))

        merged = Image.alpha_composite(bg, aurora).convert("RGB")
        full_bg = merged.filter(ImageFilter.GaussianBlur(radius=18)).resize((width, height), Image.Resampling.BICUBIC).convert("RGBA")

        for (x1, y1, x2, y2, rad, alpha) in glass_cards:
            w, h = x2 - x1, y2 - y1
            sub = full_bg.crop((x1, y1, x2, y2)).filter(ImageFilter.GaussianBlur(radius=12))
            tint = Image.new("RGBA", (w, h), (255, 255, 255, alpha))
            frosted = Image.alpha_composite(sub, tint)

            mask = Image.new("L", (w, h), 0)
            ImageDraw.Draw(mask).rounded_rectangle((0, 0, w - 1, h - 1), radius=rad, fill=255)
            full_bg.paste(frosted, (x1, y1), mask)

            overlay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            ImageDraw.Draw(overlay).rounded_rectangle(
                (0, 0, w - 1, h - 1), radius=rad, outline=(226, 232, 240, 235), width=1
            )
            full_bg.alpha_composite(overlay, (x1, y1))

        return full_bg

    def render_toast_Graphic(w: int, h: int, accent_rgb: tuple, icon_char: str) -> ImageTk.PhotoImage:
        """
        Disegna una pillola Toast ad alta risoluzione con Pillow (Anti-aliasing 2x,
        ombra morbida reale e zero angoli spigolosi di Tkinter).
        """
        scale = 2
        sw, sh = w * scale, h * scale
        pad = 12 * scale
        img = Image.new("RGBA", (sw, sh), (0, 0, 0, 0))

        # 1. Ombra morbida sottostante (Drop Shadow)
        shadow = Image.new("RGBA", (sw, sh), (0, 0, 0, 0))
        sdraw = ImageDraw.Draw(shadow)
        sdraw.rounded_rectangle(
            (pad, pad + 4 * scale, sw - pad, sh - pad + 2 * scale),
            radius=22 * scale,
            fill=(15, 23, 42, 75)
        )
        shadow = shadow.filter(ImageFilter.GaussianBlur(radius=8 * scale))
        img = Image.alpha_composite(img, shadow)

        # 2. Corpo della Pillola Dark Slate (#0F172A) con bordo luminoso sottile
        draw = ImageDraw.Draw(img)
        draw.rounded_rectangle(
            (pad, pad, sw - pad, sh - pad),
            radius=22 * scale,
            fill=(15, 23, 42, 248),
            outline=(51, 65, 85, 255),
            width=2
        )

        # 3. Cerchio colorato dell'icona (perfettamente anti-aliasato)
        cx1, cy1 = pad + 16 * scale, (sh // 2) - 18 * scale
        cx2, cy2 = cx1 + 36 * scale, cy1 + 36 * scale
        draw.ellipse((cx1, cy1, cx2, cy2), fill=(*accent_rgb, 255))

        smooth = img.resize((w, h), Image.Resampling.LANCZOS)
        return ImageTk.PhotoImage(smooth)

    class DriverManagerGUI(ctk.CTk):
        W, H = 1100, 760

        def __init__(self):
            super().__init__()
            self.title("DriverCore • Shared Hardware Intelligence")
            self.geometry(f"{self.W}x{self.H}")
            self.resizable(False, False)

            self.nv_info = None
            self.deep_updates = []
            self.checkbox_vars = []
            self.slim_mode = True
            self.clean_mode = False
            self.is_busy = False
            self.scan_phase = 0.0
            self._anim_after_id = None
            self._toast_after_id = None
            self._toast_anim_id = None
            self._toast_img_ref = None

            self.glass_cards = [
                (36, 14, 1064, 104, 24, 95),
                (58, 32, 1042, 86, 27, 235),
                (36, 222, 1064, 274, 26, 242),
                (36, 290, 535, 468, 22, 245),
                (565, 290, 1064, 468, 22, 245),
                (36, 484, 1064, 742, 22, 245),
            ]

            self.canvas = tk.Canvas(self, width=self.W, height=self.H, highlightthickness=0, bd=0)
            self.canvas.pack(fill="both", expand=True)

            self.bg_pil = build_auralis_background(self.W, self.H, self.glass_cards)
            self.bg_tk = ImageTk.PhotoImage(self.bg_pil)
            self.canvas.create_image(0, 0, image=self.bg_tk, anchor="nw")

            self._draw_typography()
            self._build_real_buttons()
            self._build_fullwidth_peripherals_view()

            interceptor = ModernEventInterceptor(self)
            sys.stdout = interceptor
            sys.stderr = interceptor
            ds_console.file = interceptor
            dc_console.file = interceptor
            di_console.file = interceptor
            cl_console.file = interceptor
            for _c in (ds_console, dc_console, di_console, cl_console):
                _c.width = 400  # Rich andrebbe a capo a 80 colonne spezzando le righe nei log e nei toast

            self.after(300, lambda: self.show_toast(
                "DriverCore Studio Attivo",
                "Scansione silenziosa WMI e catalogo WHQL avviata...",
                "info"
            ))
            self.run_in_background(self._task_full_scan)

        def show_toast(self, title: str, message: str, kind: str = "success"):
            """
            Disegna una notifica Dynamic Island / Toast nativa sul Canvas (centrata sopra le card,
            con vera ombra Alpha, zero sovrapposizioni con la scrollbar e testo intero).
            """
            palette = {
                "success": ((16, 185, 129), "✔"),
                "info":    ((99, 102, 241), "⚡"),
                "warning": ((245, 158, 11), "!"),
                "error":   ((239, 68, 68), "✖"),
            }
            accent_rgb, icon_char = palette.get(kind, palette["info"])

            if self._toast_after_id:
                self.after_cancel(self._toast_after_id)
                self._toast_after_id = None
            if self._toast_anim_id:
                self.after_cancel(self._toast_anim_id)
                self._toast_anim_id = None

            self.canvas.delete("canvas_toast")

            tw = 560
            cx = self.W // 2
            text_x = cx - tw // 2 + 78

            # Il messaggio va a capo e il toast si adatta all'altezza del testo (niente più troncamenti)
            clean_msg = message if len(message) <= 260 else message[:257] + "..."
            msg_id = self.canvas.create_text(
                text_x, -1000, text=clean_msg, font=("Segoe UI", 10), fill="#CBD5E1",
                anchor="nw", width=tw - 78 - 28, tags="canvas_toast"
            )
            bb = self.canvas.bbox(msg_id)
            msg_h = (bb[3] - bb[1]) if bb else 16
            pill_h = max(64, 48 + msg_h)
            th = pill_h + 24
            self._toast_img_ref = render_toast_Graphic(tw, th, accent_rgb, icon_char)

            # Bordo alto fisso (come prima); il toast cresce verso il basso
            target_y = 104 + th // 2
            start_y = target_y - 33
            pill_top = start_y - pill_h // 2

            img_id = self.canvas.create_image(cx, start_y, image=self._toast_img_ref, anchor="center", tags="canvas_toast")
            ico_id = self.canvas.create_text(
                cx - tw // 2 + 46, start_y - 1, text=icon_char,
                font=("Segoe UI", 14, "bold"), fill="#FFFFFF", tags="canvas_toast"
            )
            ttl_id = self.canvas.create_text(
                text_x, pill_top + 22, text=title,
                font=("Segoe UI", 11, "bold"), fill="#FFFFFF", anchor="w", tags="canvas_toast"
            )
            self.canvas.coords(msg_id, text_x, pill_top + 34)
            self.canvas.tag_raise(msg_id)
            self.canvas.tag_bind("canvas_toast", "<Button-1>", lambda e: self.canvas.delete("canvas_toast"))

            def step_anim(cur_y):
                if cur_y < target_y:
                    dy = min(4, target_y - cur_y)
                    for item in (img_id, ico_id, ttl_id, msg_id):
                        self.canvas.move(item, 0, dy)
                    self._toast_anim_id = self.after(12, lambda: step_anim(cur_y + dy))

            step_anim(start_y)
            duration = min(10000, 4200 + max(0, len(clean_msg) - 70) * 45)  # più testo = più tempo (clic per chiudere)
            self._toast_after_id = self.after(duration, lambda: self.canvas.delete("canvas_toast"))

        def update_live_subtitle(self, text: str):
            self.canvas.itemconfigure(self.id_hero_sub, text=text, fill="#4F46E5")

        def _draw_typography(self):
            self.canvas.create_text(
                82, 59, text="DriverCore Studio", font=("Segoe UI", 13, "bold"),
                fill="#0F172A", anchor="w"
            )
            self.canvas.create_line(240, 45, 240, 73, fill="#CBD5E1", width=1)

            self.canvas.create_text(
                self.W // 2, 122,
                text="POWERED BY WMI  •  WHQL GLOBAL CATALOG  •  NVIDIA DIRECT API  •  PNPUTIL",
                font=("Segoe UI", 8, "bold"), fill="#64748B", anchor="center"
            )
            self.id_hero_title = self.canvas.create_text(
                self.W // 2, 150,
                text="Two engines, one shared hardware layer",
                font=("Segoe UI", 23, "bold"), fill="#0B0D12", anchor="center"
            )
            self.id_hero_sub = self.canvas.create_text(
                self.W // 2, 180,
                text="Scansione silenziosa Zero-Bloatware per GPU NVIDIA, Chipset AMD e periferiche WHQL.",
                font=("Segoe UI", 10), fill="#64748B", anchor="center"
            )

            self.canvas.create_text(
                62, 248, text="⚡ PRO TOOLKIT", font=("Segoe UI", 9, "bold"),
                fill="#6366F1", anchor="w"
            )
            self.canvas.create_line(175, 234, 175, 262, fill="#E2E8F0", width=1)

            self.canvas.create_text(
                60, 310, text="PRIMARY DISPLAY ENGINE", font=("Segoe UI", 8, "bold"),
                fill="#6366F1", anchor="nw"
            )
            self.id_nv_title = self.canvas.create_text(
                60, 330, text="NVIDIA GeForce RTX 5070", font=("Segoe UI", 16, "bold"),
                fill="#0F172A", anchor="nw"
            )
            self.id_nv_sub = self.canvas.create_text(
                60, 360, text="Verifica versione WMI e release WHQL in corso...",
                font=("Segoe UI", 10), fill="#475569", anchor="nw"
            )
            self.id_nv_badge = self.canvas.create_text(
                60, 386, text="● IN ATTESA DI SCANSIONE", font=("Segoe UI", 9, "bold"),
                fill="#64748B", anchor="nw"
            )

            self.canvas.create_text(
                590, 310, text="WHQL DEEP CATALOG STATUS", font=("Segoe UI", 8, "bold"),
                fill="#0EA5E9", anchor="nw"
            )
            self.id_counter_big = self.canvas.create_text(
                590, 334, text="00", font=("Segoe UI", 38, "bold"),
                fill="#0F172A", anchor="nw"
            )
            self.canvas.create_text(
                665, 346, text="Pacchetti Driver\nDisponibili", font=("Segoe UI", 11, "bold"),
                fill="#334155", anchor="nw"
            )
            self.id_status_dot = self.canvas.create_oval(590, 424, 600, 434, fill="#10B981", outline="")
            self.id_status_txt = self.canvas.create_text(
                608, 429, text="Sistema Pronto • Notifiche Dynamic Island attive",
                font=("Segoe UI", 10, "bold"), fill="#334155", anchor="w"
            )

            self.canvas.create_text(
                60, 504, text="Periferiche & Chipset  •  Microsoft Update Catalog",
                font=("Segoe UI", 13, "bold"), fill="#0F172A", anchor="nw"
            )

            self._draw_scanner_bar(ratio=1.0, scanning=False)

        def _build_real_buttons(self):
            nav_style = {
                "height": 34,
                "corner_radius": 17,
                "fg_color": "#F1F5F9",
                "hover_color": "#E2E8F0",
                "text_color": "#334155",
                "bg_color": "#F5F7FA",
                "font": ctk.CTkFont(family="Segoe UI", size=12, weight="bold"),
            }

            self.btn_nav_backup = ctk.CTkButton(
                self, text="Backup Driver", width=130,
                command=lambda: self.run_in_background(backup_current_drivers), **nav_style
            )
            self.btn_nav_backup.place(x=260, y=42)

            self.btn_nav_runtime = ctk.CTkButton(
                self, text="Runtime Gaming", width=140,
                command=lambda: self.run_in_background(update_game_runtimes), **nav_style
            )
            self.btn_nav_runtime.place(x=402, y=42)

            self.btn_nav_clean = ctk.CTkButton(
                self, text="Pulisci DriverStore", width=155,
                command=lambda: self.run_in_background(self._task_cleanup_driverstore), **nav_style
            )
            self.btn_nav_clean.place(x=554, y=42)

            self.btn_deep_scan = ctk.CTkButton(
                self, text="Deep Scan", width=132, height=36, corner_radius=18,
                fg_color="#0F172A", hover_color="#1E293B", text_color="#FFFFFF",
                bg_color="#F5F7FA", font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"),
                command=lambda: self.run_in_background(self._task_full_scan)
            )
            self.btn_deep_scan.place(x=894, y=41)

            toolkit_style = {
                "height": 34,
                "corner_radius": 17,
                "fg_color": "#F8FAFC",
                "hover_color": "#E0E7FF",
                "text_color": "#1E293B",
                "border_width": 1,
                "border_color": "#CBD5E1",
                "bg_color": "#FAFBFD",
                "font": ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            }

            self.btn_tool_restore_pt = ctk.CTkButton(
                self, text="🛡️ Punto di Ripristino", width=195,
                command=lambda: self.run_in_background(create_system_restore_point), **toolkit_style
            )
            self.btn_tool_restore_pt.place(x=192, y=231)

            self.btn_tool_shader = ctk.CTkButton(
                self, text="✨ Pulisci Cache Shader", width=195,
                command=lambda: self.run_in_background(clean_gpu_shader_cache), **toolkit_style
            )
            self.btn_tool_shader.place(x=400, y=231)

            self.btn_tool_msi = ctk.CTkButton(
                self, text="🚀 Ottimizza MSI Mode GPU", width=215,
                command=lambda: self.run_in_background(self._task_msi_mode), **toolkit_style
            )
            self.btn_tool_msi.place(x=608, y=231)

            self.btn_tool_rollback = ctk.CTkButton(
                self, text="⏪ Ripristina da Backup", width=205,
                command=self._select_and_restore_backup, **toolkit_style
            )
            self.btn_tool_rollback.place(x=836, y=231)

            self.btn_toggle_slim = ctk.CTkButton(
                self, text="", width=152, height=36, corner_radius=18,
                bg_color="#FAFBFD", font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
                command=lambda: self._toggle("slim")
            )
            self.btn_toggle_slim.place(x=58, y=416)

            self.btn_toggle_clean = ctk.CTkButton(
                self, text="", width=140, height=36, corner_radius=18,
                bg_color="#FAFBFD", font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
                command=lambda: self._toggle("clean")
            )
            self.btn_toggle_clean.place(x=218, y=416)

            self._refresh_toggles_ui()

            self.btn_gpu_update = ctk.CTkButton(
                self, text="Aggiorna GPU", width=144, height=38, corner_radius=19,
                fg_color="#0F172A", hover_color="#1E293B", text_color="#FFFFFF",
                bg_color="#FAFBFD", font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"),
                command=self._on_update_gpu
            )
            self.btn_gpu_update.place(x=368, y=415)

            self.btn_install_sel = ctk.CTkButton(
                self, text="Installa Selezionati", width=176, height=36, corner_radius=18,
                fg_color="#0F172A", hover_color="#1E293B", text_color="#FFFFFF",
                bg_color="#FAFBFD", font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"),
                command=self._on_install_selected
            )
            self.btn_install_sel.place(x=864, y=496)

        def _refresh_toggles_ui(self):
            if self.slim_mode:
                self.btn_toggle_slim.configure(
                    text="● SLIM No-Telemetry",
                    fg_color="#E0E7FF", hover_color="#C7D2FE",
                    text_color="#1E1B4B", border_width=1, border_color="#6366F1"
                )
            else:
                self.btn_toggle_slim.configure(
                    text="○ SLIM No-Telemetry",
                    fg_color="#F1F5F9", hover_color="#E2E8F0",
                    text_color="#64748B", border_width=1, border_color="#CBD5E1"
                )

            if self.clean_mode:
                self.btn_toggle_clean.configure(
                    text="● Clean (-clean)",
                    fg_color="#E0E7FF", hover_color="#C7D2FE",
                    text_color="#1E1B4B", border_width=1, border_color="#6366F1"
                )
            else:
                self.btn_toggle_clean.configure(
                    text="○ Clean (-clean)",
                    fg_color="#F1F5F9", hover_color="#E2E8F0",
                    text_color="#64748B", border_width=1, border_color="#CBD5E1"
                )

        def _toggle(self, which: str):
            if which == "slim":
                self.slim_mode = not self.slim_mode
                state_str = "attivata" if self.slim_mode else "disattivata"
                self.show_toast("Modalità SLIM NVIDIA", f"Rimozione telemetria e bloatware {state_str}.", "info")
            else:
                self.clean_mode = not self.clean_mode
                state_str = "attivata" if self.clean_mode else "disattivata"
                self.show_toast("Installazione Pulita", f"Parametro -clean {state_str}.", "info")
            self._refresh_toggles_ui()

        def _draw_scanner_bar(self, ratio: float = 1.0, scanning: bool = False):
            self.canvas.delete("scan_bar")
            x1, y1, x2, y2 = 300, 200, 800, 206
            w = x2 - x1
            cy = (y1 + y2) // 2

            self.canvas.create_line(
                x1, cy, x2, cy, fill="#E2E8F0", width=6, capstyle="round", tags="scan_bar"
            )

            if not scanning:
                fill_w = max(10, int(w * max(0.02, min(1.0, ratio))))
                self.canvas.create_line(
                    x1, cy, x1 + fill_w, cy, fill="#0F172A", width=6, capstyle="round", tags="scan_bar"
                )
            else:
                norm = (math.sin(self.scan_phase) + 1.0) / 2.0
                seg_w = int(w * 0.30)
                sx = int(x1 + norm * (w - seg_w))
                ex = sx + seg_w
                self.canvas.create_line(
                    max(x1, sx - 16), cy, min(x2, ex + 16), cy,
                    fill="#BAE6FD", width=6, capstyle="round", tags="scan_bar"
                )
                self.canvas.create_line(
                    max(x1, sx - 6), cy, min(x2, ex + 6), cy,
                    fill="#C084FC", width=6, capstyle="round", tags="scan_bar"
                )
                self.canvas.create_line(
                    sx, cy, ex, cy,
                    fill="#0F172A", width=6, capstyle="round", tags="scan_bar"
                )

        def _animate_scanner(self):
            if not self.is_busy:
                return
            self.scan_phase += 0.07
            self._draw_scanner_bar(scanning=True)
            self._anim_after_id = self.after(16, self._animate_scanner)

        def _build_fullwidth_peripherals_view(self):
            self.scroll_list = ctk.CTkScrollableFrame(
                self, width=968, height=175, corner_radius=16,
                fg_color="#F8FAFC", bg_color="#FAFBFD",
                scrollbar_button_color="#CBD5E1", scrollbar_button_hover_color="#94A3B8"
            )
            self.scroll_list.place(x=56, y=540)

        def _set_busy(self, busy: bool, message: str = "Sistema Pronto"):
            self.is_busy = busy
            state = "disabled" if busy else "normal"
            for btn in (
                self.btn_nav_backup, self.btn_nav_runtime, self.btn_nav_clean,
                self.btn_deep_scan, self.btn_gpu_update, self.btn_install_sel,
                self.btn_tool_restore_pt, self.btn_tool_shader, self.btn_tool_msi, self.btn_tool_rollback
            ):
                btn.configure(state=state)

            self.canvas.itemconfigure(self.id_status_txt, text=message)
            self.canvas.itemconfigure(self.id_status_dot, fill="#6366F1" if busy else "#10B981")

            if busy:
                if not self._anim_after_id:
                    self._animate_scanner()
            else:
                if self._anim_after_id:
                    self.after_cancel(self._anim_after_id)
                    self._anim_after_id = None
                self.canvas.itemconfigure(
                    self.id_hero_sub,
                    text="Scansione silenziosa Zero-Bloatware per GPU NVIDIA, Chipset AMD e periferiche WHQL.",
                    fill="#64748B"
                )
                self._draw_scanner_bar(ratio=1.0, scanning=False)

        def run_in_background(self, target_func):
            if self.is_busy:
                return
            # Impostato subito nel thread UI: due click ravvicinati non avviano due operazioni
            self.is_busy = True
            self._set_busy(True, "Elaborazione operazione in corso...")

            def wrapper():
                pythoncom.CoInitialize()
                try:
                    target_func()
                except Exception as e:
                    self.after(0, self.show_toast, "Errore Esecuzione", str(e), "error")
                finally:
                    pythoncom.CoUninitialize()
                    self.after(0, self._set_busy, False, "Sistema Pronto • Tutti i moduli verificati")

            threading.Thread(target=wrapper, daemon=True).start()

        def _task_full_scan(self):
            c = wmi.WMI()
            self.nv_info = check_nvidia_update(c)
            self.after(0, self._update_nvidia_ui)

            self.deep_updates = deep_scan_peripherals(c)
            self.after(0, self._update_peripherals_ui)

        def _task_msi_mode(self):
            c = wmi.WMI()
            enable_gpu_msi_mode(c)

        def _select_and_restore_backup(self):
            if self.is_busy:
                return
            chosen = filedialog.askdirectory(
                initialdir=str(BACKUP_DIR),
                title="Seleziona la cartella di Backup Driver da ripristinare"
            )
            if chosen and messagebox.askyesno(
                "Ripristina da Backup",
                f"Reinstallare i driver della cartella:\n{chosen}\n\n"
                "Se il driver più recente è ancora installato, Windows potrebbe mantenerlo attivo.\n\n"
                "Procedere?"
            ):
                self.run_in_background(lambda: restore_driver_backup_folder(chosen))

        def _update_nvidia_ui(self):
            if not self.nv_info:
                self.canvas.itemconfigure(self.id_nv_title, text="GPU NVIDIA non rilevata")
                return
            self.canvas.itemconfigure(self.id_nv_title, text=self.nv_info["name"])
            self.canvas.itemconfigure(
                self.id_nv_sub,
                text=f"Build installata: {self.nv_info['local']}   •   Ultima release WHQL: {self.nv_info['remote']}"
            )
            if self.nv_info["update"]:
                self.canvas.itemconfigure(self.id_nv_badge, text="● NUOVO DRIVER DISPONIBILE", fill="#D97706")
                self.show_toast("Aggiornamento GPU Disponibile", f"Nuovo driver NVIDIA {self.nv_info['remote']} WHQL pronto.", "warning")
            else:
                self.canvas.itemconfigure(self.id_nv_badge, text="● DRIVER AGGIORNATO ALL'ULTIMA BUILD", fill="#10B981")
            self._refresh_counter()

        def _refresh_counter(self):
            total = len(self.deep_updates) + (1 if self.nv_info and self.nv_info.get("update") else 0)
            self.canvas.itemconfigure(self.id_counter_big, text=f"{total:02d}")

        def _update_peripherals_ui(self):
            for widget in self.scroll_list.winfo_children():
                widget.destroy()
            self.checkbox_vars.clear()
            self._refresh_counter()

            if not self.deep_updates:
                lbl = ctk.CTkLabel(
                    self.scroll_list,
                    text="✔ Tutte le periferiche PCI, USB, Audio e Chipset sono aggiornate all'ultima build WHQL!",
                    text_color="#0F172A", font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold")
                )
                lbl.grid(row=0, column=0, padx=16, pady=28, sticky="w")
                return

            for idx, item in enumerate(self.deep_updates):
                var = ctk.BooleanVar(value=True)
                self.checkbox_vars.append((var, item))
                text = (
                    f"{item['name']}  [{item['hwid']}]   •   "
                    f"Installato: {item['local_ver']} ({item['local_date'].strftime('%Y-%m-%d')})  ➔  "
                    f"Nuovo WHQL: {item['remote_ver']} ({item['remote_date']})"
                )
                cb = ctk.CTkCheckBox(
                    self.scroll_list, text=text, variable=var,
                    text_color="#0F172A", fg_color="#0F172A", hover_color="#334155",
                    font=ctk.CTkFont(family="Consolas", size=12)
                )
                cb.grid(row=idx, column=0, padx=12, pady=8, sticky="w")

        def _ask_yes_no(self, title: str, message: str) -> bool:
            """Chiede conferma dal thread di lavoro: la finestra si apre nel thread UI, il lavoro attende la risposta."""
            result = {"v": False}
            done = threading.Event()

            def ask():
                try:
                    result["v"] = messagebox.askyesno(title, message)
                finally:
                    done.set()

            self.after(0, ask)
            done.wait()
            return result["v"]

        def _task_cleanup_driverstore(self):
            c = wmi.WMI()
            candidates = find_obsolete_driver_packages(c)
            if candidates:
                lines = "\n".join(
                    f" • {o['driver']}  {o['provider']} / {o['class']}  {o['version']}  (resta {o['kept_version']})"
                    for o in candidates[:15]
                )
                if len(candidates) > 15:
                    lines += f"\n … e altri {len(candidates) - 15}"
                ok = self._ask_yes_no(
                    "Pulisci DriverStore",
                    f"Trovati {len(candidates)} pacchetti driver obsoleti (per ognuno resta il più recente).\n"
                    "I driver in uso non vengono toccati.\n\n"
                    f"{lines}\n\n"
                    "Prima verranno creati un punto di ripristino e un backup. Procedere?"
                )
                if not ok:
                    print("! Pulizia DriverStore annullata.")
                    return
                create_system_restore_point("DriverCore Pre-DriverStore Cleanup")  # non bloccante
                if not backup_current_drivers():
                    print("✖ Backup driver non riuscito: pulizia annullata.")
                    return
                remove_obsolete_driver_packages(candidates)
            cleanup_old_driver_packages()  # DISM sui componenti di sistema

        def _on_update_gpu(self):
            """Gestore del pulsante (thread UI): chiede conferma, poi avvia il lavoro in background."""
            if self.is_busy:
                return
            if not self.nv_info:
                self.show_toast("GPU non disponibile", "Esegui prima una scansione (Deep Scan).", "warning")
                return
            mode = "SLIM" if self.slim_mode else "STANDARD"
            extra = " + installazione pulita (-clean)" if self.clean_mode else ""
            if not messagebox.askyesno(
                "Aggiorna GPU NVIDIA",
                f"Verrà scaricato e installato il driver NVIDIA {self.nv_info['remote']}\n"
                f"Modalità: {mode}{extra}\n\n"
                "Prima verranno creati un punto di ripristino e un backup dei driver.\n"
                "Lo schermo può lampeggiare durante l'installazione.\n\n"
                "Procedere?"
            ):
                return
            info = dict(self.nv_info)
            slim, clean = self.slim_mode, self.clean_mode
            self.run_in_background(lambda: self._task_update_nvidia(info, slim, clean))

        def _on_install_selected(self):
            """Gestore del pulsante (thread UI): legge la selezione qui, non nel thread di lavoro."""
            if self.is_busy:
                return
            selected = [item for var, item in self.checkbox_vars if var.get()]
            if not selected:
                self.show_toast("Nessuna Selezione", "Seleziona almeno una periferica dalla lista.", "warning")
                return
            names = "\n".join(f" • {i['name']}  ➔  {i['remote_ver']}" for i in selected[:12])
            if len(selected) > 12:
                names += f"\n … e altri {len(selected) - 12}"
            if not messagebox.askyesno(
                "Installa driver selezionati",
                f"Verranno installati {len(selected)} driver dal Microsoft Update Catalog:\n\n{names}\n\n"
                "Prima verranno creati un punto di ripristino e un backup dei driver.\n\n"
                "Procedere?"
            ):
                return
            self.run_in_background(lambda: self._task_install_peripherals(selected))

        def _task_update_nvidia(self, nv_info: dict, slim: bool, clean: bool):
            create_system_restore_point("DriverCore Pre-NVIDIA Update")  # non bloccante: avvisa se non riesce
            if not backup_current_drivers():
                print("✖ Backup driver non riuscito: aggiornamento NVIDIA annullato.")
                return
            exe_path = download_file(nv_info["url"])
            if not exe_path:
                return
            installed = install_nvidia_driver(exe_path, clean_install=clean, slim_mode=slim)
            if installed:
                clean_gpu_shader_cache()
            self._task_full_scan()

        def _task_install_peripherals(self, selected: list):
            create_system_restore_point("DriverCore Pre-Peripherals Update")  # non bloccante
            if not backup_current_drivers():
                print("✖ Backup driver non riuscito: installazione annullata.")
                return
            install_catalog_cab_updates(selected)
            self._task_full_scan()

    if __name__ == "__main__":
        app = DriverManagerGUI()
        app.mainloop()

except Exception:
    err_msg = traceback.format_exc()
    (LOG_DIR / "gui_error.log").write_text(f"[{datetime.now():%Y-%m-%d %H:%M:%S}]\n{err_msg}", encoding="utf-8")
    ctypes.windll.user32.MessageBoxW(0, err_msg, "Errore Avvio Driver Manager", 0x10)
