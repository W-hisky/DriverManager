﻿import wmi
import httpx
import win32com.client
from packaging import version
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

console = Console()

def wmi_to_nvidia_version(wmi_ver: str) -> str:
    """Converte la versione WMI (es. 32.0.16.2101) nel formato NVIDIA (es. 621.01)"""
    clean_digits = wmi_ver.replace(".", "")
    last_five = clean_digits[-5:]
    return f"{last_five[:3]}.{last_five[3:]}"

def check_nvidia_update(c):
    console.print("\n[bold cyan][1/3] Controllo API Ufficiale NVIDIA (GeForce Game Ready WHQL)...[/bold cyan]")
    gpus = [gpu for gpu in c.Win32_VideoController() if "NVIDIA" in (gpu.Name or "")]
    if not gpus:
        console.print("[yellow]Nessuna GPU NVIDIA rilevata.[/yellow]")
        return None

    gpu = gpus[0]
    local_ver = wmi_to_nvidia_version(gpu.DriverVersion)

    # Endpoint JSON ufficiale NVIDIA (psid=131: RTX 50 Series, osID=57: Win 10/11 64-bit, dch=1)
    url = (
        "https://gfwsl.geforce.com/services_toolkit/services/com/nvidia/services/"
        "AjaxDriverService.php?func=DriverManualLookup&psid=131&osID=57"
        "&languageCode=1040&beta=0&isWHQL=1&dltype=-1&dch=1&upCRD=0&sort1=0&numberOfResults=1"
    )

    try:
        with httpx.Client(timeout=10.0) as client:
            resp = client.get(url)
            data = resp.json()
            dl_info = data["IDS"][0]["downloadInfo"]
            remote_ver = dl_info["Version"]
            release_date = dl_info.get("ReleaseDateTime", "N/A")
            dl_url = dl_info["DownloadURL"]

            is_newer = version.parse(remote_ver) > version.parse(local_ver)
            status = "[bold red]AGGIORNAMENTO DISPONIBILE[/bold red]" if is_newer else "[bold green]AGGIORNATO[/bold green]"

            console.print(Panel(
                f"[bold]GPU:[/bold] {gpu.Name}\n"
                f"[bold]Versione Installata:[/bold] {local_ver} (WMI: {gpu.DriverVersion})\n"
                f"[bold]Ultima Versione WHQL:[/bold] {remote_ver} ({release_date})\n"
                f"[bold]Stato:[/bold] {status}\n"
                f"[bold]Link Diretto:[/bold] {dl_url}",
                title="Report Driver GPU NVIDIA",
                border_style="cyan"
            ))
            return {"name": gpu.Name, "local": local_ver, "remote": remote_ver, "url": dl_url, "update": is_newer}
    except Exception as e:
        console.print(f"[red]Errore durante l'interrogazione dell'API NVIDIA: {e}[/red]")
        return None

def list_third_party_drivers(c):
    console.print("\n[bold cyan][2/3] Inventario Driver Hardware Principali (Non-Microsoft)...[/bold cyan]")
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Classe", style="cyan", width=16)
    table.add_column("Dispositivo", style="white", width=38)
    table.add_column("Fornitore", style="green", width=18)
    table.add_column("Versione", style="yellow", width=16)
    table.add_column("Data", style="dim", width=12)

    target_classes = {"Display", "Net", "Media", "System", "SCSIAdapter", "USB", "HIDClass"}
    seen = set()

    for drv in c.Win32_PnPSignedDriver():
        if not drv.DeviceName or not drv.DriverVersion:
            continue
        if drv.DriverProviderName in ("Microsoft", None) or drv.DeviceClass not in target_classes:
            continue
        key = (drv.DeviceName, drv.DriverVersion)
        if key in seen:
            continue
        seen.add(key)
        drv_date = drv.DriverDate[:8] if drv.DriverDate else "N/A"
        table.add_row(drv.DeviceClass or "N/A", drv.DeviceName[:36], drv.DriverProviderName[:16], drv.DriverVersion, drv_date)

    console.print(table)

def check_windows_update_drivers():
    console.print("\n[bold cyan][3/3] Scansione Catalogo Windows Update (Driver WHQL Opzionali/Chipset)...[/bold cyan]")
    session = win32com.client.Dispatch("Microsoft.Update.Session")
    searcher = session.CreateUpdateSearcher()
    result = searcher.Search("IsInstalled=0 and Type='Driver'")

    if result.Updates.Count == 0:
        console.print("[bold green]✔ Nessun driver mancante o obsoleto rilevato sul catalogo Microsoft.[/bold green]")
        return []

    wua_table = Table(title="Driver Disponibili su Catalogo Microsoft")
    wua_table.add_column("#", style="cyan")
    wua_table.add_column("Titolo Pacchetto", style="yellow")
    wua_table.add_column("Classe", style="green")

    updates = []
    for i in range(result.Updates.Count):
        upd = result.Updates.Item(i)
        wua_table.add_row(str(i + 1), upd.Title, getattr(upd, "DriverClass", "Hardware"))
        updates.append(upd)

    console.print(wua_table)
    return updates

if __name__ == "__main__":
    wmi_client = wmi.WMI()
    check_nvidia_update(wmi_client)
    list_third_party_drivers(wmi_client)
    check_windows_update_drivers()
