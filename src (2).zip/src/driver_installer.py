﻿import os
import shutil
import subprocess
import winreg
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

import httpx
import win32com.client
from rich.console import Console

console = Console()
BASE_DIR = Path("C:/DriverManager")
BACKUP_ROOT = BASE_DIR / "backups"
DOWNLOAD_DIR = BASE_DIR / "downloads"
SEVEN_ZIP = Path("C:/Program Files/7-Zip/7z.exe")
NO_WIN = subprocess.CREATE_NO_WINDOW


def backup_current_drivers() -> bool:
    """Esporta i driver attuali gestendo correttamente la codifica OEM italiana di Windows."""
    today_prefix = datetime.now().strftime("backup_%Y%m%d")
    BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
    existing_today = [
        d for d in BACKUP_ROOT.iterdir()
        if d.is_dir() and d.name.startswith(today_prefix) and any(d.iterdir())
    ]

    if existing_today:
        console.print(f"[bold green]✔ Backup odierno già presente in {existing_today[0]} (salto nuova esportazione).[/bold green]")
        return True

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    target_dir = BACKUP_ROOT / f"backup_{timestamp}"
    target_dir.mkdir(parents=True, exist_ok=True)

    console.print(f"\n[bold cyan]Avvio backup driver in:[/bold cyan] {target_dir}")
    try:
        proc = subprocess.Popen(
            ["pnputil", "/export-driver", "*", str(target_dir)],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="oem",
            errors="replace",
            creationflags=NO_WIN
        )
        count = 0
        if proc.stdout:
            for line in proc.stdout:
                if ".inf" in line.lower():
                    count += 1
        proc.wait()

        # Il backup è valido solo se pnputil ha finito bene e ha esportato qualcosa
        if proc.returncode not in (0, 3010) or not any(target_dir.iterdir()):
            console.print(f"[bold red]✖ Backup fallito (pnputil codice {proc.returncode}, {count} riferimenti).[/bold red]")
            shutil.rmtree(target_dir, ignore_errors=True)
            return False

        console.print(f"[bold green]✔ Backup completato con successo ({count} riferimenti elaborati).[/bold green]")
        return True
    except Exception as e:
        console.print(f"[bold red]✖ Errore durante il backup: {e}[/bold red]")
        shutil.rmtree(target_dir, ignore_errors=True)
        return False


def verify_signature(path: Path, expected_signer: str) -> bool:
    """Verifica la firma Authenticode del file e che il firmatario contenga `expected_signer`."""
    ps = (
        f"$s = Get-AuthenticodeSignature -LiteralPath '{path}'; "
        "if ($s.Status -ne 'Valid') { Write-Output ('STATUS:' + $s.Status); exit 2 }; "
        "Write-Output $s.SignerCertificate.Subject"
    )
    try:
        res = subprocess.run(
            ["powershell.exe", "-NoProfile", "-Command", ps],
            capture_output=True, text=True, encoding="oem", errors="replace",
            creationflags=NO_WIN, timeout=60
        )
    except Exception as e:
        console.print(f"[bold red]✖ Impossibile verificare la firma di {path.name}: {e}[/bold red]")
        return False

    out = (res.stdout or "").strip()
    if res.returncode != 0:
        console.print(f"[bold red]✖ Firma digitale non valida per {path.name} ({out or 'nessun dettaglio'}).[/bold red]")
        return False
    if expected_signer.lower() not in out.lower():
        console.print(f"[bold red]✖ Firmatario inatteso per {path.name}: {out}[/bold red]")
        return False
    return True


def download_file(url: str) -> Path | None:
    """Scarica il pacchetto driver mostrando l'avanzamento. Riusa il file se già completo in cache."""
    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    filename = Path(urlparse(url).path).name or "driver_download.exe"
    dest_path = DOWNLOAD_DIR / filename
    part_path = dest_path.with_suffix(dest_path.suffix + ".part")

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "Referer": "https://www.nvidia.com/"
    }

    console.print(f"\n[bold cyan]Download di:[/bold cyan] {filename}")
    try:
        with httpx.Client(follow_redirects=True, timeout=30.0, headers=headers) as client:
            with client.stream("GET", url) as response:
                response.raise_for_status()
                total = int(response.headers.get("Content-Length", 0))

                if dest_path.exists() and total > 0 and dest_path.stat().st_size == total:
                    console.print(f"[bold green]✔ File già scaricato in cache: {dest_path}[/bold green]")
                    return dest_path

                downloaded = 0
                last_pct = -1
                with open(part_path, "wb") as f:
                    for chunk in response.iter_bytes(chunk_size=65536):
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total > 0:
                            pct = int((downloaded / total) * 100)
                            if pct % 10 == 0 and pct != last_pct:
                                last_pct = pct
                                console.print(f" -> Avanzamento download: {pct}% ({downloaded // (1024*1024)} MB / {total // (1024*1024)} MB)")

        if total > 0 and downloaded != total:
            raise IOError(f"download incompleto ({downloaded} di {total} byte)")

        part_path.replace(dest_path)
        console.print(f"[bold green]✔ File salvato in:[/bold green] {dest_path}")
        return dest_path
    except Exception as e:
        part_path.unlink(missing_ok=True)
        console.print(f"[bold red]✖ Errore durante il download: {e}[/bold red]")
        return None


def install_nvidia_driver(exe_path: Path, clean_install: bool = False, slim_mode: bool = True) -> bool:
    """Installa il driver NVIDIA in modalità Slim (stile NVCleanstall) o Standard. Ritorna True se riuscito."""
    # Non eseguire mai un installer con firma mancante/non valida o di un altro firmatario
    if not verify_signature(exe_path, "NVIDIA"):
        console.print("[bold red]✖ Installazione annullata: il pacchetto non risulta firmato da NVIDIA.[/bold red]")
        return False

    target_exe = exe_path
    extract_dir = DOWNLOAD_DIR / "nvidia_slim_temp"

    if slim_mode:
        if not SEVEN_ZIP.exists():
            console.print("[yellow]! 7-Zip non trovato in C:\\Program Files\\7-Zip\\7z.exe. Passo alla modalità standard.[/yellow]")
        else:
            if extract_dir.exists():
                shutil.rmtree(extract_dir, ignore_errors=True)
            extract_dir.mkdir(parents=True, exist_ok=True)

            console.print("\n[bold cyan]Estrazione selettiva pacchetto NVIDIA (Solo Display.Driver, PhysX, HDAudio)...[/bold cyan]")
            components = [
                "Display.Driver",
                "HDAudio",
                "PhysX",
                "NVI2",
                "EULA.txt",
                "ListDevices.txt",
                "setup.cfg",
                "setup.exe"
            ]
            cmd = [str(SEVEN_ZIP), "x", str(exe_path), f"-o{extract_dir}", "-y"] + components
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False, creationflags=NO_WIN)

            cfg_path = extract_dir / "setup.cfg"
            slim_setup = extract_dir / "setup.exe"
            if cfg_path.exists() and slim_setup.exists():
                blocked_tokens = ("EulaHtmlFile", "FunctionalConsentFile", "PrivacyPolicyFile")
                lines = cfg_path.read_text(encoding="utf-8", errors="ignore").splitlines()
                cleaned_lines = [line for line in lines if not any(tok in line for tok in blocked_tokens)]
                cfg_path.write_text("\n".join(cleaned_lines), encoding="utf-8")
                target_exe = slim_setup
                console.print("[bold green]✔ Pacchetto alleggerito e telemetria rimossa da setup.cfg.[/bold green]")
            else:
                console.print("[yellow]! Estrazione SLIM incompleta (setup.cfg/setup.exe mancanti). Passo alla modalità standard.[/yellow]")

    args = [str(target_exe), "-passive", "-noreboot"]
    if clean_install:
        args.append("-clean")

    console.print(f"\n[bold cyan]Avvio installazione NVIDIA ({'SLIM' if target_exe != exe_path else 'STANDARD'})...[/bold cyan]")
    console.print("[dim]Lo schermo potrebbe lampeggiare per alcuni secondi.[/dim]")

    ok = False
    try:
        proc = subprocess.run(args, check=False, creationflags=NO_WIN)
        if proc.returncode in (0, 3010):
            console.print("[bold green]✔ Installazione NVIDIA completata con successo![/bold green]")
            if proc.returncode == 3010:
                console.print("[bold yellow]! Riavvio del sistema consigliato.[/bold yellow]")
            ok = True
        else:
            console.print(f"[bold red]✖ L'installer ha restituito il codice: {proc.returncode}[/bold red]")
    except Exception as e:
        console.print(f"[bold red]✖ Errore esecuzione installer: {e}[/bold red]")
    finally:
        if extract_dir.exists():
            shutil.rmtree(extract_dir, ignore_errors=True)
    return ok


def install_windows_update_drivers(updates):
    """Scarica e installa i driver trovati nel catalogo Windows Update."""
    if not updates:
        return

    session = win32com.client.Dispatch("Microsoft.Update.Session")
    coll = win32com.client.Dispatch("Microsoft.Update.UpdateColl")
    for u in updates:
        coll.Add(u)

    console.print(f"\n[bold cyan]Download di {coll.Count} driver dal catalogo Microsoft...[/bold cyan]")
    downloader = session.CreateUpdateDownloader()
    downloader.Updates = coll
    downloader.Download()

    console.print("[bold cyan]Installazione driver Windows Update in corso...[/bold cyan]")
    installer = session.CreateUpdateInstaller()
    installer.Updates = coll
    res = installer.Install()

    # ResultCode WUA: 2 = Succeeded, 3 = SucceededWithErrors, 4 = Failed, 5 = Aborted
    if res.ResultCode == 2:
        console.print(f"[bold green]✔ Installazione completata (Riavvio richiesto: {res.RebootRequired})[/bold green]")
    else:
        console.print(f"[bold red]✖ Installazione non riuscita o parziale (ResultCode: {res.ResultCode}, Riavvio richiesto: {res.RebootRequired})[/bold red]")


def update_game_runtimes() -> bool:
    """Aggiorna librerie di sistema VC++ e .NET tramite winget. Ritorna True se nessun pacchetto è fallito."""
    packages = [
        "Microsoft.VCRedist.2015+.x64",
        "Microsoft.VCRedist.2015+.x86",
        "Microsoft.DotNet.DesktopRuntime.8",
        "Microsoft.DotNet.DesktopRuntime.10",
    ]
    # Codici winget che NON sono errori: nessun aggiornamento applicabile / già installato
    # (confrontati come interi senza segno: winget può restituirli anche come negativi)
    winget_ok = {
        0,
        0x8A15002B,  # aggiornamento non applicabile (già all'ultima versione)
        0x8A150061,  # pacchetto già installato
    }
    console.print("\n[bold cyan]Verifica e aggiornamento Runtime di gioco (VC++ / .NET)...[/bold cyan]")
    failed = []
    for pkg in packages:
        console.print(f" -> Controllo [yellow]{pkg}[/yellow]...")
        try:
            res = subprocess.run(
                ["winget", "upgrade", "--id", pkg, "--silent",
                 "--accept-package-agreements", "--accept-source-agreements"],
                check=False,
                creationflags=NO_WIN
            )
        except FileNotFoundError:
            console.print("[bold red]✖ winget non trovato: installa 'App Installer' dal Microsoft Store.[/bold red]")
            return False
        code = res.returncode & 0xFFFFFFFF
        if code == 0x8A150014:
            # Nessun pacchetto installato corrisponde all'ID: niente da aggiornare, non è un errore
            console.print(f"[dim] -> {pkg} non è installato: salto.[/dim]")
            continue
        if code not in winget_ok:
            failed.append((pkg, f"0x{code:08X}"))

    if failed:
        details = ", ".join(f"{p} (codice {c})" for p, c in failed)
        console.print(f"[bold red]✖ Aggiornamento runtime non riuscito per: {details}[/bold red]")
        return False
    console.print("[bold green]✔ Controllo runtime terminato.[/bold green]")
    return True


def create_system_restore_point(description: str = "DriverCore Pre-Update") -> bool:
    """Crea un Punto di Ripristino di Windows tramite PowerShell Checkpoint-Computer."""
    console.print(f"\n[bold cyan]Creazione Punto di Ripristino di Sistema ({description})...[/bold cyan]")
    safe_desc = description.replace("'", "''")
    cmd = [
        "powershell.exe", "-NoProfile", "-Command",
        f"Checkpoint-Computer -Description '{safe_desc}' -RestorePointType 'DEVICE_DRIVER_INSTALL' -ErrorAction Stop"
    ]
    res = subprocess.run(cmd, capture_output=True, text=True, encoding="oem", errors="replace", creationflags=NO_WIN)
    if res.returncode == 0:
        console.print("[bold green]✔ Punto di ripristino di Windows creato con successo.[/bold green]")
        return True

    reason = (res.stderr or res.stdout or "").strip().splitlines()
    reason_txt = reason[0][:160] if reason else f"codice {res.returncode}"
    console.print(f"[yellow]! Punto di ripristino non creato: {reason_txt}[/yellow]")
    return False


def clean_gpu_shader_cache():
    """Svuota le cache DirectX e NVIDIA DXCache/GLCache per eliminare stuttering post-aggiornamento."""
    console.print("\n[bold cyan]Pulizia Cache Shader GPU (NVIDIA DXCache, GLCache, DirectX D3DSCache)...[/bold cyan]")
    local_app = Path(os.environ.get("LOCALAPPDATA", ""))
    target_dirs = [
        local_app / "NVIDIA" / "DXCache",
        local_app / "NVIDIA" / "GLCache",
        local_app / "D3DSCache",
        local_app / "Temp" / "NVIDIA Corporation" / "NV_Cache"
    ]
    freed_files = 0
    freed_bytes = 0
    for d in target_dirs:
        if d.exists():
            for item in d.rglob("*"):
                if item.is_file():
                    try:
                        sz = item.stat().st_size
                        item.unlink()
                        freed_files += 1
                        freed_bytes += sz
                    except (PermissionError, OSError):
                        # File in uso (es. dal compositore desktop di Windows)
                        pass
    mb_freed = freed_bytes / (1024 * 1024)
    console.print(f"[bold green]✔ Cache Shader ripulita: {freed_files} file rimossi ({mb_freed:.1f} MB liberati).[/bold green]")


def enable_gpu_msi_mode(wmi_client):
    """Verifica e attiva Message Signaled Interrupts (MSI Mode) nel registro PCI per la GPU NVIDIA."""
    console.print("\n[bold cyan]Verifica e attivazione MSI Low-Latency Mode sulla GPU...[/bold cyan]")
    gpus = [g for g in wmi_client.Win32_VideoController() if "NVIDIA" in (g.Name or "")]
    if not gpus:
        console.print("[yellow]! Nessuna GPU NVIDIA trovata per l'ottimizzazione MSI.[/yellow]")
        return

    for gpu in gpus:
        pnp_id = gpu.PNPDeviceID
        if not pnp_id:
            continue
        reg_path = f"SYSTEM\\CurrentControlSet\\Enum\\{pnp_id}\\Device Parameters\\Interrupt Management\\MessageSignaledInterruptProperties"
        key = None
        try:
            key = winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, reg_path, 0, winreg.KEY_READ | winreg.KEY_WRITE)
            try:
                cur_val, _ = winreg.QueryValueEx(key, "MSISupported")
            except FileNotFoundError:
                cur_val = 0

            if cur_val == 1:
                console.print(f"[bold green]✔ {gpu.Name}: MSI Low-Latency Mode è GIÀ ATTIVO (MSISupported = 1).[/bold green]")
            else:
                winreg.SetValueEx(key, "MSISupported", 0, winreg.REG_DWORD, 1)
                console.print(f"[bold green]✔ {gpu.Name}: MSI Mode ATTIVATO con successo! (valore precedente: {cur_val}; riavvia il PC per applicare).[/bold green]")
        except Exception as e:
            console.print(f"[red]✖ Impossibile accedere alla chiave MSI di {gpu.Name}: {e}[/red]")
        finally:
            if key is not None:
                winreg.CloseKey(key)


def restore_driver_backup_folder(folder_path: str) -> bool:
    """Reinstalla i driver .inf presenti in una cartella di backup selezionata.

    NB: Windows sceglie comunque il driver "migliore" tra quelli disponibili: se il driver
    più nuovo è ancora installato, potrebbe restare attivo. Per un vero rollback serve
    anche rimuovere il pacchetto nuovo (pnputil /delete-driver).
    """
    target = Path(folder_path)
    if not target.exists():
        console.print(f"[bold red]✖ Cartella di backup non trovata: {target}[/bold red]")
        return False
    console.print(f"\n[bold cyan]Ripristino driver dalla cartella:[/bold cyan] {target.name}")
    res = subprocess.run(
        ["pnputil", "/add-driver", str(target / "*.inf"), "/subdirs", "/install"],
        capture_output=True, text=True, encoding="oem", errors="replace", creationflags=NO_WIN
    )
    if res.returncode in (0, 3010):
        console.print(f"[bold green]✔ Reinstallazione completata da {target.name} (codice {res.returncode}).[/bold green]")
        return True
    console.print(f"[bold red]✖ Ripristino non riuscito da {target.name} (codice {res.returncode}).[/bold red]")
    return False
