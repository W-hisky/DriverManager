﻿import ctypes
import sys
import wmi
from rich.console import Console
from rich.prompt import Prompt, Confirm

from driver_scanner import (
    check_nvidia_update,
    list_third_party_drivers,
    check_windows_update_drivers,
)
from driver_installer import (
    backup_current_drivers,
    download_file,
    install_nvidia_driver,
    install_windows_update_drivers,
    update_game_runtimes,
)
from driver_cleanup import find_obsolete_driver_packages, remove_obsolete_driver_packages
from deep_catalog import (
    deep_scan_peripherals,
    install_catalog_cab_updates,
    cleanup_old_driver_packages,
)

console = Console()

def ensure_admin():
    if ctypes.windll.shell32.IsUserAnAdmin() == 0:
        console.print("[bold red]✖ Errore: Avvia il programma come Amministratore.[/bold red]")
        sys.exit(1)

def main():
    ensure_admin()
    c = wmi.WMI()

    nv_info = check_nvidia_update(c)
    list_third_party_drivers(c)
    wua_updates = check_windows_update_drivers()
    deep_updates = []

    while True:
        console.print("\n[bold magenta]=== PERSONAL DRIVER MANAGER PRO MENU ===[/bold magenta]")
        console.print("1. Esegui Backup completo dei driver attuali (pnputil)")
        console.print("2. Aggiorna GPU NVIDIA (Modalità Slim Zero-Telemetria / Standard)")
        console.print("3. [bold yellow][DEEP SCAN][/bold yellow] Cerca aggiornamenti per TUTTE le periferiche (Chipset, LAN, Audio, USB)")
        console.print("4. Installa driver standard da Windows Update")
        console.print("5. Aggiorna Runtime di Gioco (Visual C++ / .NET)")
        console.print("6. Rimuovi pacchetti driver obsoleti dal DriverStore e pulisci componenti di sistema")
        console.print("7. Ripeti scansione base")
        console.print("0. Esci")

        choice = Prompt.ask("\nSeleziona un'opzione", choices=["0", "1", "2", "3", "4", "5", "6", "7"], default="3")

        if choice == "0":
            console.print("[cyan]Uscita completata.[/cyan]")
            break

        elif choice == "1":
            backup_current_drivers()

        elif choice == "2":
            if not nv_info:
                console.print("[yellow]Informazioni GPU NVIDIA non disponibili.[/yellow]")
                continue
            if not nv_info["update"]:
                if not Confirm.ask("Il driver NVIDIA risulta già aggiornato. Vuoi scaricarlo comunque?"):
                    continue
            if Confirm.ask("Vuoi eseguire un backup dei driver prima di procedere?", default=True):
                backup_current_drivers()

            exe_path = download_file(nv_info["url"])
            if exe_path and Confirm.ask("Avviare l'installazione del driver NVIDIA ora?", default=True):
                slim = Confirm.ask("Usare la modalità SLIM (rimuove telemetria e bloatware NVIDIA)?", default=True)
                clean = Confirm.ask("Eseguire un'installazione pulita (-clean)?", default=False)
                install_nvidia_driver(exe_path, clean_install=clean, slim_mode=slim)

        elif choice == "3":
            deep_updates = deep_scan_peripherals(c)
            if deep_updates and Confirm.ask(f"\nVuoi scaricare e installare i {len(deep_updates)} aggiornamenti WHQL trovati?", default=True):
                if Confirm.ask("Eseguire un backup di sicurezza prima dell'installazione?", default=True):
                    backup_current_drivers()
                install_catalog_cab_updates(deep_updates)

        elif choice == "4":
            if not wua_updates:
                console.print("[green]Nessun driver in sospeso su Windows Update locale.[/green]")
                continue
            if Confirm.ask("Vuoi eseguire un backup dei driver prima di procedere?", default=True):
                backup_current_drivers()
            install_windows_update_drivers(wua_updates)

        elif choice == "5":
            update_game_runtimes()

        elif choice == "6":
            candidates = find_obsolete_driver_packages(c)
            if candidates:
                for o in candidates:
                    console.print(f" • {o['driver']}  {o['provider']} / {o['class']}  {o['version']}  (resta {o['kept_version']})")
                if Confirm.ask(f"Rimuovere questi {len(candidates)} pacchetti obsoleti?", default=False):
                    if backup_current_drivers():
                        remove_obsolete_driver_packages(candidates)
                    else:
                        console.print("[bold red]✖ Backup non riuscito: pulizia annullata.[/bold red]")
            cleanup_old_driver_packages()

        elif choice == "7":
            nv_info = check_nvidia_update(c)
            list_third_party_drivers(c)
            wua_updates = check_windows_update_drivers()

if __name__ == "__main__":
    main()
